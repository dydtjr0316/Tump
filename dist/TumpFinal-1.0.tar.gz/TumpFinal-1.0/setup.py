from distutils.core import setup, Extension
setup(name="TumpFinal",
      version="1.0",
      py_modules=["TumpFinal"]
      )
